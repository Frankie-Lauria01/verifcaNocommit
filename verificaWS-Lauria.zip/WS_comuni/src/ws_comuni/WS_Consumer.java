/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws_comuni;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.HttpsURLConnection;
/**
 *
 * @author lauria_francesco
 */
public class WS_Consumer {
    String result="";
    int getComune(String nomeComune){
        
        String prefix = "http://localhost/wsComuni/getComune.php?";
        int status = 0;
        result = "";

        try {
            URL serverURL;
            HttpURLConnection service;
            BufferedReader input;

            String url = prefix
                    + URLEncoder.encode("comune", "UTF-8") + "="
                    + URLEncoder.encode(nomeComune, "UTF-8");
            serverURL = new URL(url);

            System.out.println("REST: "+url);

            service = (HttpURLConnection) serverURL.openConnection();
            // impostazione header richiesta
            service.setRequestProperty("Host", "localhost");
            service.setRequestProperty("Accept", "application/text");
            service.setRequestProperty("Accept-Charset", "UTF-8");
            // impostazione metodo di richiesta GET
            service.setRequestMethod("GET");
            // attivazione ricezione
            service.setDoInput(true);
            // connessione al web-service
            service.connect();
            // verifica stato risposta
            status = service.getResponseCode();
            if (status != 200) {
                return status; // non OK
            }
            // apertura stream di ricezione da risorsa web
            input = new BufferedReader(new InputStreamReader(service.getInputStream(), "UTF-8"));
            // ciclo di lettura da web e scrittura in result
            String line;
            while ((line = input.readLine()) != null) {
                result += line + "\n";
            }
            input.close();

        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return status;
    }
    
    
    
    

    int ricercaByProvincia(String provincia) {
         
        String prefix;
        prefix = "http://localhost/wsComuni/getComuniByProvincia.php?";
        int status = 0;
        result = "";

        try {
            URL serverURL;
            HttpURLConnection service;
            BufferedReader input;

            String url = prefix
                    + URLEncoder.encode("provincia", "UTF-8") + "="
                    + URLEncoder.encode(provincia, "UTF-8");
            serverURL = new URL(url);

            System.out.println("REST: "+url);

            service = (HttpURLConnection) serverURL.openConnection();
            // impostazione header richiesta
            service.setRequestProperty("Host", "localhost");
            service.setRequestProperty("Accept", "application/text");
            service.setRequestProperty("Accept-Charset", "UTF-8");
            // impostazione metodo di richiesta GET
            service.setRequestMethod("GET");
            // attivazione ricezione
            service.setDoInput(true);
            // connessione al web-service
            service.connect();
            // verifica stato risposta
            status = service.getResponseCode();
            if (status != 200) {
                return status; // non OK
            }
            // apertura stream di ricezione da risorsa web
            input = new BufferedReader(new InputStreamReader(service.getInputStream(), "UTF-8"));
            // ciclo di lettura da web e scrittura in result
            String line;
            while ((line = input.readLine()) != null) {
                result += line + "\n";
            }
            input.close();

        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return status;
    }

    int updatePop(String comune, String pop) {
         String prefix;
        prefix = "http://localhost/wsComuni/updateComune.php?";
        int status = 0;
        result = "";

        try {
            URL serverURL;
            HttpURLConnection service;
            BufferedReader input;

            String url = prefix
                    + URLEncoder.encode("comune", "UTF-8") + "="
                    + URLEncoder.encode(comune, "UTF-8")+ "&"
                    + URLEncoder.encode("pop", "UTF-8") + "="
                    + URLEncoder.encode(pop, "UTF-8");
            serverURL = new URL(url);

            System.out.println("REST: "+url);

            service = (HttpURLConnection) serverURL.openConnection();
            // impostazione header richiesta
            service.setRequestProperty("Host", "localhost");
            service.setRequestProperty("Accept", "application/text");
            service.setRequestProperty("Accept-Charset", "UTF-8");
            // impostazione metodo di richiesta PUT
            service.setRequestMethod("PUT");
            // attivazione ricezione
            service.setDoInput(true);
            // connessione al web-service
            service.connect();
            // verifica stato risposta
            status = service.getResponseCode();
            if (status != 200) {
                return status; // non OK
            }
            // apertura stream di ricezione da risorsa web
            input = new BufferedReader(new InputStreamReader(service.getInputStream(), "UTF-8"));
            // ciclo di lettura da web e scrittura in result
            String line;
            while ((line = input.readLine()) != null) {
                result += line + "\n";
            }
            input.close();

        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return status;
    }
    
    int ricercaProvince(String regione){
        String prefix;
        prefix = "http://localhost/wsComuni/getProvince.php?";
        int status = 0;
        result = "";

        try {
            URL serverURL;
            HttpURLConnection service;
            BufferedReader input;

            String url = prefix
                    + URLEncoder.encode("regione", "UTF-8") + "="
                    + URLEncoder.encode(regione, "UTF-8");
            serverURL = new URL(url);

            System.out.println("REST: "+url);

            service = (HttpURLConnection) serverURL.openConnection();
            // impostazione header richiesta
            service.setRequestProperty("Host", "localhost");
            service.setRequestProperty("Accept", "application/text");
            service.setRequestProperty("Accept-Charset", "UTF-8");
            // impostazione metodo di richiesta GET
            service.setRequestMethod("GET");
            // attivazione ricezione
            service.setDoInput(true);
            // connessione al web-service
            service.connect();
            // verifica stato risposta
            status = service.getResponseCode();
            if (status != 200) {
                return status; // non OK
            }
            // apertura stream di ricezione da risorsa web
            input = new BufferedReader(new InputStreamReader(service.getInputStream(), "UTF-8"));
            // ciclo di lettura da web e scrittura in result
            String line;
            while ((line = input.readLine()) != null) {
                result += line + "\n";
            }
            input.close();

        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(WS_Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return status;
    }
    void printResult() {
        String[] arrOfStr = result.split(";");
        System.out.println("ID-comune-provincia-regione-popolazione");
        for (int i = 0; i < arrOfStr.length; i++) {
            System.out.println(arrOfStr[i]);
        }
        System.out.println("\r\n");
    }

    void printResultComuni(){
        
        String[] arrOfStr = result.split(";");
        System.out.println("comune-popolazione");
        for (int i = 0; i < arrOfStr.length; i++) {
            if(i%2==0)
                System.out.print(arrOfStr[i]+"-");
            else{
                System.out.print(arrOfStr[i]);
                System.out.println("\r\n");
            }
        }

    }
    void printResultUpdating() {
        
        String[] arrOfStr = result.split(";");
        
        for (int i = 0; i < arrOfStr.length; i++) {
            System.out.println(arrOfStr[i]+"-");
        }
        System.out.println("\r\n");
    }

    void printResultProvince() {
        
         String[] arrOfStr = result.split(";");
        
        for (int i = 0; i < arrOfStr.length; i++) {
            System.out.println(arrOfStr[i]);
        }
        System.out.println("\r\n");
    }
}
