/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws_comuni;

import java.util.Scanner;

/**
 *
 * @author lauria_francesco
 */
public class WS_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       WS_Consumer webService = new WS_Consumer();
       
       int i=1;
       
       do{
            System.out.println("WebService comuni");
            System.out.println("Operazioni che puoi fare:");
            System.out.println("1- Ottiene informazioni da un comune");
            System.out.println("2- Aggiornamento della popolazione corrente di un comune");
            System.out.println("3- Visualizza i comuni di una provincia");
            System.out.println("4- Ricerca tutte le province data una regione");
            System.out.println("0- Termina il programma");
            
            Scanner scanner = new Scanner(System.in);

            String comando = scanner.nextLine();
            int result = -1;
            
            
            switch (comando) {
                case "1":
                    System.out.println("Inserisci il nome del comune");
                    String nomeComune = scanner.nextLine();
                    result = webService.getComune(nomeComune);

                    System.out.println(result);

                    webService.printResult();
                    
                    break;
                case "3":
                    System.out.println("Inserisci il nome della provincia");
                    String provincia = scanner.nextLine();
                    
                    result = webService.ricercaByProvincia(provincia);

                    System.out.println(result);

                    webService.printResultComuni();
                    break;
                case "2":
                    System.out.println("Di quale comune vuoi aggiornare la popolazione?");
                    String comune = scanner.nextLine();
                    
                    System.out.println("inserisci la popolazione:");
                    String pop = scanner.nextLine();
                    
                    result = webService.updatePop(comune, pop);
                    webService.printResultUpdating();
                    i=1;
                    
                    break;
                    
                case "4":
                    System.out.println("Inserisci regione:");
                    String reg = scanner.nextLine();
                    
                    result = webService.ricercaProvince(reg);
                    webService.printResultProvince();
                    i=1;
                    
                    break;
                
                case "0":
                    i=0;
                    break;
            }
            
    }while(i==1);
    
}
}
