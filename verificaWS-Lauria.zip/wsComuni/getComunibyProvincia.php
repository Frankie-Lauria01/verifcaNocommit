 <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "verifica02";

    //prendo parametro passato dal link
 $prov=$_GET["provincia"];

   include("connessione.php");
    
    $sql = "SELECT * FROM comuni WHERE provincia='$prov'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        while ($row = $result->fetch_assoc()) {
            //stampo il risultato
            echo $row["comune"]. ";" .$row["pop_residente"].";";
        }
    } else {
        echo "Nessun risultato trovato.";
    }
    $conn->close();


?>
    