 <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "verifica02";

    //prendo parametro passato dal link
    $pop= $_GET["pop"];
    $comune=$_GET["comune"];

   include("connessione.php");
    
    $sql = "UPDATE comuni SET pop_residente='$pop' WHERE comune='$comune'";
    $result = $conn->query($sql);

    if ($result===TRUE) {
        echo "Comune aggiornato correttamente!";
    }
    else {
        echo "Nessun risultato trovato. Error: ".$conn->error;
    }
    $conn->close();


?>
   