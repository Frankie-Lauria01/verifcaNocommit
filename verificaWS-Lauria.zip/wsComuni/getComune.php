 <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "verifica02";

    //prendo parametro passato dal link
 $comune=$_GET["comune"];

   include("connessione.php");
    
    $sql = "SELECT * FROM comuni WHERE comune='$comune'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        while ($row = $result->fetch_assoc()) {
            //stampo il risultato
            echo $row["id"]. ";" .$row["comune"]. ";" .$row["provincia"]. ";" .$row["regione"]. ";" .$row["pop_residente"].";";
        }
    } else {
        echo "Nessun risultato trovato.";
    }
    $conn->close();


?>
    