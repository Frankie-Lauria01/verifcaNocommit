   <?php
   $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "verifica02";

    //prendo parametro passato dal link
    $regione=$_GET["regione"];

   include("connessione.php");
    
    $sql = "SELECT DISTINCT provincia FROM `comuni` WHERE regione='$regione'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        while ($row = $result->fetch_assoc()) {
            //stampo il risultato
            echo $row["provincia"].";";
        }
    } else {
        echo "Nessuna provincia trovata.";
    }
    $conn->close();
?>
